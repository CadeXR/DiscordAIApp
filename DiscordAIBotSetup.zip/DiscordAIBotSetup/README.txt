Discord AI Bot App Documentation

Welcome to the Discord AI Bot App. This documentation will guide you through the first-time setup and usage of the application. This guide assumes you have no coding experience and will walk you through each step necessary to get the app running smoothly.

---

Prerequisites

Before running the app, there are a few requirements that need to be set up:

1. Python (from the Windows Store)
You must have Python installed on your machine. You can easily get it from the Windows Store.
Install Python from the Microsoft Store.
After installation, ensure that Python is added to your system's environment variables (this is normally done automatically, but see the troubleshooting section if you encounter issues).

2. Windows .NET Framework
The application relies on Windows .NET Framework. If you don’t have it installed, the app will prompt you to install it.
Simply follow the on-screen instructions to install the .NET Framework if needed.

---

First-Time Setup Guide

After the prerequisites are met, follow these steps to get the bot up and running for the first time:

1. Get Your OpenAI API Key
The bot relies on OpenAI's API for generating responses. You'll need your own API key for this.
Visit OpenAI API Keys.
Sign in or create an account if needed.
Click "Create new secret key" and copy the key.
Save the key somewhere safe as you will need to input it into the app.
For more detailed instructions on setting up an OpenAI API key, check out this OpenAI API Guide.

2. Create Your Discord Bot
You'll need to create a Discord bot and obtain a token to connect the bot to your Discord server.

How to create a Discord Bot:

Go to the Discord Developer Portal and log in with your Discord account.
Click on New Application in the top right.
Name your application, click Create.
In the Bot section (on the left-hand menu), click Add Bot and confirm by clicking Yes, do it!.
Scroll down and Enable Privileged Gateway Intents (both "Message Content Intent" and other intents as needed).
Copy your Bot Token by clicking Copy under TOKEN. This will be used in the application.
Invite the bot to your server:

Under OAuth2 in the developer portal, click on URL Generator.
Under Scopes, check the box for bot.
Scroll down to Bot Permissions and check the permissions you need (at least read and send messages).
Copy the generated URL, paste it into your browser, and select the server where you'd like to add the bot.
The bot will now be part of your server and can interact with users.

---

First-Time Startup

Once you have Python installed, an OpenAI API Key, and a Discord bot token, follow these steps:

Run the app by double-clicking on the DiscordAIApp.exe file.
On the first run, you will need to click on the "Setup Python Environment" button to ensure all the necessary Python dependencies are installed.
The app will install dependencies like discord.py and requests.
Enter your OpenAI API key, Discord Token, and your preferred Wake Word (this is the word the bot will listen for to respond).

---

Understanding the Application

Here are some key features of the application:

1. OpenAI Model Selection
You can select between OpenAI models such as:

gpt-3.5-turbo: Faster but less capable than GPT-4. This model is cost-effective and recommended for most use cases.
gpt-4: More powerful but more expensive and slightly slower than GPT-3.5. Use this model if you need more nuanced or complex responses.
Note: Using higher-end models like GPT-4 will increase token costs and may take more time to generate responses.

2. Memory System (Short-Term Memory)
This app has a Short-Term Memory system that allows the bot to remember recent conversations for better contextual understanding.

How It Works: The bot will store user messages and its responses in temporary memory. This memory is cleared every 5 minutes to ensure that the bot does not accumulate unnecessary context, keeping costs low and response times faster.
Effect on Token Usage: If short-term memory is enabled, the bot will refer back to recent messages when crafting its replies, increasing token usage. Disabling this feature will make responses faster and more cost-effective, but with less context.

3. Prompt File
The prompt.txt file is where you can define a custom system message that will guide the bot’s overall behavior.

How to Edit: You can open this file by clicking the "Open Prompt File" button in the app. The text you input here will be used as a base prompt for the bot every time it generates a response.
Example: You can include something like "You are a helpful assistant" to make the bot more polite and responsive.

---

Using the Bot

Once setup is complete, you can now run the bot:

Click the Run button. The bot will start and connect to your Discord server.
Mention the bot or use your Wake Word in a message to ask the bot questions.
The bot will reply with its answer, and if enabled, it will use short-term memory to provide more contextual answers.

---

Troubleshooting

Python Not Found
If the app shows an error that Python cannot be found, it is likely that Python is not installed or not added to your system PATH. Follow these steps:

Install Python from the Microsoft Store: Install Python.
Restart your computer after installation.
Ensure Python is accessible in Command Prompt:

Open a Command Prompt window and type python --version. This should return the installed Python version.
If Python is not recognized, ensure Python is added to your system's PATH (refer to the troubleshooting section above).

